import {React,Component} from 'react'

import {auth} from './firebaseSeller'
import { useHistory } from 'react-router'


export default function HomeSeller({user}) {
    const history=useHistory()
    return (
        <div>
        {
            user ? history.push('/add')
            
            
             : <button>Login</button> 
            
        }
        </div>
    )
}


