// For Firebase JS SDK v7.20.0 and later, measurementId is optional
import   firebase from "firebase";
const secondaryAppConfig = {
    apiKey: "AIzaSyCmIFRNfmznyNAmWlEhgKBKJWVr-I1EsjE",
    authDomain: "amaon-clone-seller.firebaseapp.com",
    projectId: "amaon-clone-seller",
    storageBucket: "amaon-clone-seller.appspot.com",
    messagingSenderId: "689083532997",
    appId: "1:689083532997:web:1debe30327a732dabd52ac",
    measurementId: "G-LXFJBXF15R",
    databaseURL:"https://amaon-clone-seller-default-rtdb.firebaseio.com"
  };
  const secondaryApp = firebase.initializeApp(secondaryAppConfig,"secondary");

  const db=secondaryApp.firestore();
  const auth =secondaryApp.auth();
  const storage=secondaryApp.storage();
  const database=secondaryApp.database();

  export{database,storage,auth,db ,secondaryApp  as default };