import React, { useEffect } from "react";
import {db,auth} from './firebaseSeller'
import firebase from "./firebaseSeller";
import './AddProduct.css';
import { useHistory } from "react-router";




function Addproduct1() {
  const [fileUrl, setFileUrl] = React.useState(null);
  const [users, setUsers] = React.useState([]);
  const [id,setID]=React.useState('')
 const history=useHistory()


  const onFileChange = async (e) => {
    const file = e.target.files[0];
    const storageRef = firebase.storage().ref();
    const fileRef = storageRef.child(file.name);
    await fileRef.put(file);
    setFileUrl(await fileRef.getDownloadURL());
  };
  
  auth.onAuthStateChanged(user=>
    {
      if(user!=null)
      {
        setID(user.uid)
        
        
        

      }

    })


  const onSubmit = async (e) => {
    e.preventDefault();
    
   const productName=e.target.productName.value;
   const Description=e.target.Description.value;
   const cost=e.target.cost.value;
   try
   {
    if ( !fileUrl || !productName|| ! Description ||!cost) {
      return;
    }
    await db.collection("users").doc(productName).set({
       productname:productName,
      avatar: fileUrl,
      description:Description,
      price:cost,
      userId:id

    });
  
    }catch(err)
    {
       console.log(err.message)
    }  
  }
  useEffect(() => {
    const fetchUsers = async () => {
      const usersCollection = await db.collection("users").get();
      setUsers(
        usersCollection.docs.map((doc) => {
          return doc.data();
        })
      );
    };
    fetchUsers();
  }, []);
 

      
  return (
      <>
    <div className="login">
                <div>
            <img className="login_logo"
            src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt=""/>
        </div>
       
            <h1>Become an
         <br/>Amazon seller</h1>
         <form onSubmit={onSubmit}>
        <div className="container">
         
         <h3><label >Product Name </label></h3>
        <input id="post" className="ProductName" name="productName" type='text'/>
        <br/>
       <h3>  <label >Product Image </label> </h3>
        <input type="file"  id="image"className="image-upload" onChange={onFileChange} accept=".jpg,.png,jpeg"  />
        <br/>
     <h3>  <label> Description </label></h3>
        <input  className="Description"type="text" name="Description"/>
        <br></br>
      <h3><label>  Price </label></h3>
                  <input className="Price" type="text" name="cost"/>
                  <button className="upload_button"type="submit" >Upload</button>
                  
                  <button onClick={()=>
                  {
                    auth.signOut()
                    history.push('/LoginSeller')
                  }}>Logout</button>
                    
                  

  
        </div>
        </form>
     
          <div className="product">
            
          
        {users.map((user) => {
          return (
            
            <div className="display" key={user.userId}>
              <div className="produt-info">
              <img className="img" src={user.avatar} alt={user.productName}  />
              
             
              <p className="product-info">{user.productname}</p>
              <p className="product-info">{user.description}</p>
              <p className="product-info">{user.price}</p>
              
              </div>

            </div>
            
          );
          
        })}
        </div>
     
      
        </div>
         
      
    </>
  );
}

export default Addproduct1;