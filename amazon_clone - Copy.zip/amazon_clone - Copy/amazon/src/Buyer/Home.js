import React from 'react'
import {auth1} from './firebaseBuyer'
import {useHistory} from 'react-router'
function Home(userb) {
    const history=useHistory()
    return (
        <div>
            {
                 userb ? <button onClick={()=>
                {
                    auth1.signOut()
                    history.push('/login')

                }}>Logout</button>
                 :
                 <button>Login</button>
            }
            
        </div>
    )
}

export default Home
